#include "Second.h"
Second::Second(int newNumber)
{
  itsNumber = newNumber;
}

int Second::getNumber()
{
  return itsNumber;
}
