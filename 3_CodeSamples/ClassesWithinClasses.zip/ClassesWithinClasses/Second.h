#ifndef Second_h
#define Second_h

class Second
{
  public:
    Second(int newNumber);
    int getNumber();
  private:
    int itsNumber;
};
#endif
