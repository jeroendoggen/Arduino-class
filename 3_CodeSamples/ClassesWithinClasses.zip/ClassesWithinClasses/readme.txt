Based on: http://arduinoetcetera.blogspot.be/2011/01/classes-within-classes-initialiser.html 
